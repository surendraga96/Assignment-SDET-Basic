import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

@pytest.fixture
def setup_browser():
    service = Service("C:\\drivers\\chromedriver.exe")  # Update path if needed
    driver = webdriver.Chrome(service=service)
    driver.maximize_window()
    yield driver
    driver.quit()