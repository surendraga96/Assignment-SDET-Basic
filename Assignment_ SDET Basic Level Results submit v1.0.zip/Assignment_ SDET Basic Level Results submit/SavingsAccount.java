package test;

public class SavingsAccount extends Account {

    public SavingsAccount(double balance, double interestRate) {
        super(balance, interestRate);
    }

    @Override
    public void calculateInterest() {
        System.out.println("Calculating interest for Savings Account...");
        super.calculateInterest();
    }

    @Override
    public void displayAccountInfo() {
        System.out.println("Savings Account Details:");
        super.displayAccountInfo();
    }
}