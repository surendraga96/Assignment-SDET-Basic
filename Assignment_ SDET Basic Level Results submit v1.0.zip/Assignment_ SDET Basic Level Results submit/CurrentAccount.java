package test;

public class CurrentAccount extends Account {

    public CurrentAccount(double balance, double interestRate) {
        super(balance, interestRate);
    }

    @Override
    public void calculateInterest() {
        System.out.println("Calculating interest for Current Account...");
        super.calculateInterest();
    }

    @Override
    public void displayAccountInfo() {
        System.out.println("Current Account Details:");
        super.displayAccountInfo();
    }
}