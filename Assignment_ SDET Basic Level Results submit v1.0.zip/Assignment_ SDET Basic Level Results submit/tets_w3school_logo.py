from selenium.webdriver.common.by import By
import time

def test_w3schools_logo_presence(setup_browser):
    driver = setup_browser
    driver.get("https://www.w3schools.com/")
    time.sleep(3)  # Wait for page to load

    try:
        logo = driver.find_element(By.XPATH, "//a[@id='w3schools_logo']")
        assert logo.is_displayed(), "Logo is not visible on the page"
        print("W3Schools logo is present.")
    except Exception as e:
        print(" Logo not found.")
        assert False, str(e)