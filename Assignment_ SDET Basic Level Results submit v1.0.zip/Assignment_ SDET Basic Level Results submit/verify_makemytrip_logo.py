from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
import time

# Optional: Run Firefox in headless mode (without opening browser window)
# options = Options()
# options.headless = True

# Path to your geckodriver executable
gecko_path = "C:/path/to/geckodriver.exe"  # Update this path

# Setup Firefox WebDriver
service = Service(gecko_path)
driver = webdriver.Firefox(service=service)

# Maximize window and open MakeMyTrip
driver.maximize_window()
driver.get("https://www.makemytrip.com/")

# Wait for page to load
time.sleep(5)

# Switch to iframe if needed (MakeMyTrip sometimes loads popups in iframes)
try:
    driver.switch_to.frame("webklipper-publisher-widget-container-notification-frame")
    driver.find_element(By.CLASS_NAME, "close").click()
    driver.switch_to.default_content()
except:
    pass  # No iframe popup

# Check for logo presence
try:
    logo = driver.find_element(By.CSS_SELECTOR, "img[alt='Make My Trip']")
    if logo.is_displayed():
        print("✅ MakeMyTrip logo is present on the page.")
    else:
        print("❌ Logo element found but not visible.")
except:
    print("❌ MakeMyTrip logo not found on the page.")

# Close browser
driver.quit()