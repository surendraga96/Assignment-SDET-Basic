# Define the Student class
class Student:
    def __init__(self, name, grade, age):
        self.name = name
        self.grade = grade
        self.age = age

    def display(self):
        print(f"Student Info - Name: {self.name}, Grade: {self.grade}, Age: {self.age}")

# Define the School class that inherits from Student
class School(Student):
    def SchoolStudentDisplay(self):
        print(f"School Student Info - Name: {self.name}, Grade: {self.grade}, Age: {self.age}")

# Create an object of Student class
student1 = Student("Surendra Gandla", "A", 14)
student1.display()

# Create an object of School class
school_student1 = School("Surendra", "A+", 15)
school_student1.SchoolStudentDisplay()