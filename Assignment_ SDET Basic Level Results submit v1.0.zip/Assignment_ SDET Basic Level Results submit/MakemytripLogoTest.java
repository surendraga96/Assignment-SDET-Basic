package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MakemytripLogoTest {
    public static void main(String[] args) {
        // Set path to GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\drivers\\geckodriver.exe");
        
        // Launch Firefox
        WebDriver driver = new FirefoxDriver();

        // Maximize window and open MakeMyTrip
        driver.manage().window().maximize();
        driver.get("https://www.makemytrip.com/");

        // Wait for page to load
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Close any popups or frames
        try {
            driver.switchTo().frame("webklipper-publisher-widget-container-notification-frame");
            WebElement closeBtn = driver.findElement(By.className("close"));
            closeBtn.click();
            driver.switchTo().defaultContent();
        } catch (Exception e) {
            // No popup found
        }

        // Check for logo
        try {
            WebElement logo = driver.findElement(By.cssSelector("img[alt='Make My Trip']"));
            if (logo.isDisplayed()) {
                System.out.println("✅ MakeMyTrip logo is present on the page.");
            } else {
                System.out.println("Logo element found but not visible.");
            }
        } catch (Exception e) {
            System.out.println("MakeMyTrip logo not found on the page.");
        }

        // Close browser
        driver.quit();
    }
}