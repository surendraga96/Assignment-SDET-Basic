package test;

public class Main {
    public static void main(String[] args) {
        SavingsAccount savings = new SavingsAccount(880, 9.0);
        savings.displayAccountInfo();
        savings.calculateInterest();

        System.out.println();

        CurrentAccount current = new CurrentAccount(1900, 8.5);
        current.displayAccountInfo();
        current.calculateInterest();
    }
}