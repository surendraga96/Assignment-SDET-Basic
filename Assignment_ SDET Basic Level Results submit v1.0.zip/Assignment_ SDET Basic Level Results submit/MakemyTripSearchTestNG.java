package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class MakemyTripSearchTestNG {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
      
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.makemytrip.com/");
    }

    @Test
    public void flightSearchOneWay() {
        try {
            Thread.sleep(5000);
            driver.findElement(By.xpath("//span[text()='Flights']")).click();
            driver.findElement(By.xpath("//li[@data-cy='oneWayTrip']")).click();
            driver.findElement(By.xpath("//label[@for='fromCity']")).click();
            driver.findElement(By.xpath("//input[@placeholder='From']")).sendKeys("Bangalore");
            driver.findElement(By.xpath("//label[@for='toCity']")).click();
            driver.findElement(By.xpath("//input[@placeholder='To']")).sendKeys("Delhi");
            System.out.println("Flight search input successful.");
        } catch (Exception e) {
            System.out.println("Flight search failed.");
            assert false;
        } finally {
            driver.quit();
        }
    }
}