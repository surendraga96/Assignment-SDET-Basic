package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MakeMyTripFlightSearch {

    static WebDriver driver;

    // Generic function to launch browser
    public static void launchBrowser(String url) {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(url);
        waitFor(5000); // Wait for page to load
    }

    // Generic function to click element by XPath
    public static void clickByXPath(String xpath) {
        WebElement element = driver.findElement(By.xpath(xpath));
        element.click();
        waitFor(2000);
    }

    // Generic function to enter text by XPath
    public static void enterTextByXPath(String xpath, String text) {
        WebElement element = driver.findElement(By.xpath(xpath));
        element.clear();
        element.sendKeys(text);
        waitFor(2000);
    }

    // Generic wait
    public static void waitFor(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Main test flow
    public static void main(String[] args) {
        launchBrowser("https://www.makemytrip.com/");

        // Close login popup if present
        try {
            driver.findElement(By.xpath("//span[@class='commonModal__close']")).click();
        } catch (Exception e) {
            // No popup
        }

        // Click on Flights tab
        clickByXPath("//span[text()='Flights']");

        // Click on OneWay radio button
        clickByXPath("//li[@data-cy='oneWayTrip']");

        // Click FROM and enter location
        clickByXPath("//label[@for='fromCity']");
        enterTextByXPath("//input[@placeholder='From']", "Bangalore");

        // Click TO and enter location
        clickByXPath("//label[@for='toCity']");
        enterTextByXPath("//input[@placeholder='To']", "Delhi");

        // Optional: Close browser
        waitFor(5000);
        driver.quit();
    }
}